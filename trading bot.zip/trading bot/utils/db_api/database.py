from gino import Gino
from gino.schema import GinoSchemaVisitor

import sqlalchemy

from data.config import POSTGRESURI
unix = 2113455005
db = Gino()

async def create_db():
    await db.set_bind(POSTGRESURI)
    db.gino: GinoSchemaVisitor
    await db.gino.create_all()
    