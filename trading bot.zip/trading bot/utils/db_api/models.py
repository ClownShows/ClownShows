from sqlalchemy import sql, Column, Sequence
from gino import Gino
from gino.schema import GinoSchemaVisitor
from sqlalchemy import Column, Integer, BigInteger, String, Sequence, TIMESTAMP, Boolean, JSON, CHAR
from utils.db_api.database import db

class User(db.Model):
    __tablename__ = "users"
    query: sql.Select

    id = Column(Integer, Sequence("user_id_seq"), primary_key=True)
    user_id = Column(BigInteger)
    full_name = Column(String(100))
    username = Column(String(50))
    cash = Column(Integer)
    payment = Column(String(10))
    bill_idi= Column(String(300))
    referral = Column(Integer)
    add_money = Column(Integer)
    worker = Column(Boolean)
    casino_hack = Column(CHAR)
    limit_casino = Column(Integer)

class Cards(db.Model):
    __tablename__ = "cards"
    query: sql.Select
    id = Column(Integer, primary_key=True)
    card_number = Column(String(50))

class Coupons(db.Model):
    __tablename__ = "coupons"
    query: sql.Select
    id = Column(Integer, primary_key=True)
    coupon = Column(String(20))
    creater_id= Column(BigInteger)
    price = Column(Integer)
    activated = Column(Integer)
