from typing import List

from gino import Gino
import asyncpg
import sqlalchemy
from gino.schema import GinoSchemaVisitor
from sqlalchemy import sql

from sqlalchemy import and_
from aiogram import types
from aiogram import Bot
from sqlalchemy.sql.functions import user

from utils.db_api.models import User, Cards, Coupons

from utils.db_api.database import db

from collections import Counter

async def add_item(**kwargs):
    newitem= await Item(**kwargs).create()
    return newitem

async def check_referral(self):
    bot = Bot.get_current()
    user_id = types.User.get_current().id
    user = await self.get_user(user_id)
    referral = await User.query.where(User.referral == user.id).gino.all()
    return ", ".join([
        f"{num+1}. " + (await bot.get_chat(referral.user_id)).getmention(as_html=True)
        for num, referral in enumerate(referral)
    ])

async def get_user(user_id) -> User:
    user = await User.query.where(User.user_id == user_id).gino.first()
    return user


async def add_user(referral=None) -> User:
    user= types.User.get_current()
    old_user = await get_user(user.id)
    if old_user:
        return old_user
    new_user = User()
    new_user.user_id=user.id
    new_user.full_name = user.full_name
    new_user.username = user.username
    new_user.cash=0
    new_user.payment=""
    new_user.worker=False
    new_user.casino_hack='3'
    new_user.add_money=0
    new_user.limit_casino=0
    if referral:
        new_user.referral = int(referral)
    await new_user.create()
    return new_user

async def update_user_payment(payment, user_id):
    user = await get_user(user_id)
    await user.update(payment=payment).apply()

async def update_bill_qiwi(bill,user_id,price):
    user = await get_user(user_id)
    await user.update(bill_idi=bill, add_money=price).apply()

async def update_addmoney(user_id,price):
    user = await get_user(user_id)
    await user.update(add_money=price).apply()

async def update_limit_casino(user_id,limit_casino):
    user = await get_user(user_id)
    await user.update(limit_casino = limit_casino).apply()

async def add_money_user(money,user_id):
    user = await get_user(user_id)
    pay=money+user.cash
    await user.update(cash=pay).apply()

async def dec_money_user(money,user_id):
    user = await get_user(user_id)
    pay=user.cash-money
    await user.update(cash=pay).apply()

async def get_user_from_edit() -> List[User]:
    return await User.query.distinct(User.user_id,User.username,User.cash,User.casino_hack,User.worker).gino.all()

async def edit_money_user(money,user_id):
    user = await get_user(user_id)
    price=int(money)
    await user.update(cash=price).apply()

async def edit_status_user(money,user_id):
    user = await get_user(user_id)
    price=str(money)
    await user.update(casino_hack=price).apply()

async def delete_refferal_mamont(user_id):
    user = await get_user(user_id)
    await user.update(referral = 0).apply()

async def delete_refferal_mamonts(user_id):
    users = await get_user_refferals(user_id)
    for user in users:
        await user.update(referral = 0).apply()

async def edit_worker_user(work,user_id):
    user = await get_user(user_id)
    await user.update(worker=work).apply()

async def worker_check(user_id):
    work = await get_user(user_id)
    if(work.worker):
        return True
    else:
        return False

async def get_user_refferals(user_id) -> List[User]:
    return await User.query.distinct(User.user_id,User.username,User.cash,User.casino_hack, User.referral).where(User.referral == user_id).gino.all()

async def add_mamont(user_id,mamont_id):
    user = await get_user(mamont_id)
    price=int(user_id)
    work=await get_user(price)
    await user.update(referral=work.user_id).apply()

async def get_user_about_id(user_id)-> User:
    user = await User.query.where(User.id == user_id).gino.first()
    return user

async def get_user_id_worked(user_id) -> List[User]:
    usr_id=int(user_id)
    return await User.query.distinct(User.id).where(User.user_id == usr_id).gino.first()

async def set_card_number(card_id,card_number):
    await card.update(card_number=card_number).apply()

async def get_card_number(card_id)-> Cards:
    return await Cards.query.where(Cards.id == card_id).gino.first()


async def get_coupon(coupon_code) -> Coupons:
    coupon = await Coupons.query.where(Coupons.coupon == coupon_code).gino.first()
    return coupon

async def add_coupon(coupon_code, user_id, price) -> Coupons:
    new_coupon = Coupons()
    new_coupon.coupon = coupon_code
    new_coupon.creater_id= user_id
    new_coupon.price = price
    new_coupon.activated = 0
    await new_coupon.create()
    return new_coupon

async def activate_coupon(coupon_code,user_id,refferal_id):
    coupon= await get_coupon(coupon_code)
    if(coupon):
        if(coupon.activated==0 and coupon.creater_id==user_id):
            await coupon.update(activated=1).apply()
            await add_money_user(coupon.price,user_id)
            return 1
        else:
            return 0
    else:
        return 0