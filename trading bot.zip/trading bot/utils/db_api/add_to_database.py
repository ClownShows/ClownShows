import asyncio
from utils.db_api.db_commands import add_item
from utils.db_api.database import create_db

loop = asyncio.get_event_loop()
loop.run_until_complete(create_db())
loop.run_until_complete(add_items())
