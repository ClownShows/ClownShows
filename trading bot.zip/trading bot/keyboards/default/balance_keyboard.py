from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

down_balance = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="🔙Назад"),
        ]
    ],
    resize_keyboard=True
)

up_balance = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="✔️Проверить оплату"),
            KeyboardButton(text="🔙Назад"),
        ]
    ],
    resize_keyboard=True
)