from .start_menu_keyboards import start_menu
from .admin_panel_keyboards import admin_panel
from .choose_payment_value import choose_payment, payments_list
from .balance_keyboard import up_balance, down_balance
from .option_choose_payment import option_key
from .casino_keyboards import game_stop, choose_var
from .worker_panel_keybpards import work_panel