from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

start_menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="📈 Мой ECN счёт"),
        ],
        [
            KeyboardButton(text="👨‍💻Профиль"),
            KeyboardButton(text="Настройки⚒"),
        ],
        [
            KeyboardButton(text="🌐О нас"),
        ]
    ],
    resize_keyboard=True
)