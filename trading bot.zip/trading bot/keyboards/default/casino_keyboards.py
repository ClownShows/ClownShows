from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

game_stop = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Закончить инвестирование"),
        ]
    ],
    resize_keyboard=True
)

choose_var = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Вверх📈"),
        ],
        [
            KeyboardButton(text="Не изменится"),
        ],
        [
            KeyboardButton(text="Вниз📉"),
        ],
        [
            KeyboardButton(text="Закончить инвестирование"),
        ]
    ],
    resize_keyboard=True
)

choose_hands= ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Левая рука"),
        ],
        [
            KeyboardButton(text="Правая рука"),
        ]
    ],
    resize_keyboard=True
)

choose_coin= ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Орёл"),
        ],
        [
            KeyboardButton(text="Решка"),
        ]
    ],
    resize_keyboard=True
)

choose_dice= ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Чётное"),
        ],
        [
            KeyboardButton(text="Нечётное"),
        ]
    ],
    resize_keyboard=True
)