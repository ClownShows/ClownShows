from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

choosed_game = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Amazon"),
            KeyboardButton(text="Apple"),
        ],
        [
            KeyboardButton(text="Bitcoin"),
            KeyboardButton(text="Ethereum"),
        ],
        [

            KeyboardButton(text="Tesla"),
            KeyboardButton(text="Intel"),
        ],
        [
            KeyboardButton(text="↪️ Назад"),
        ]
    ],
    resize_keyboard=True
)