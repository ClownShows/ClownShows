from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

profile_key = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="💸Пополнить"),
            KeyboardButton(text="💰Вывести"),
        ],
        [
            KeyboardButton(text="🏧Активировать промокод"),
        ],
        [
            KeyboardButton(text="🔙Назад"),
        ]
    ],
    resize_keyboard=True
)