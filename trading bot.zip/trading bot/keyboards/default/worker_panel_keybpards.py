from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

work_panel = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Список мамонтов🧨"),
        ],
        [
            KeyboardButton(text="Создать промокод🔮"),

        ],
        [
            KeyboardButton(text="Выйти"),
        ]
    ],
    resize_keyboard=True
)