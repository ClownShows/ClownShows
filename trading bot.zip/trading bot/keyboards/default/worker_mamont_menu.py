from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

work_panel = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Баланс💰"),
            KeyboardButton(text="Статус📌"),
        ],
        [
            KeyboardButton(text="Лимит"),
            KeyboardButton(text="Сообщение🔊"),
        ],
        [
            KeyboardButton(text="Удалить мамонта🗑️"),
        ],
        [
            KeyboardButton(text="Удалить мамонта🗑️"),
        ]
    ],
    resize_keyboard=True
)