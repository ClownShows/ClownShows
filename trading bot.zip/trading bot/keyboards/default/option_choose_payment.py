from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

option_key = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="💵Сменить валюту💶"),
        ],
        [
            KeyboardButton(text="🛠Техническая Поддержка🛠"),
        ],
        [
            KeyboardButton(text="🔙Назад"),
        ]
    ],
    resize_keyboard=True
)
