from keyboards.inline.cancel_key import cancel_func
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

cancel_funcion = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Отменить действие"),
        ]
    ],
    resize_keyboard=True
)