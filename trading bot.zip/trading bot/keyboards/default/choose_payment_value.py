from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

choose_payment = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Выбрать валюту"),
        ]
    ],
    resize_keyboard=True
)

payments_list = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="UAH🇺🇦"),
            KeyboardButton(text="RUB🇷🇺"),
            KeyboardButton(text="BYN🇧🇾"),
        ]
    ],
    resize_keyboard=True
)