from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

mamont_list = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="🧨Список мамонтов"),
        ],
        [
            KeyboardButton(text="🗑️Удалить всех мамонтов"),
        ],
        [
            KeyboardButton(text="🔊Рассылка всем мамонтам"),
        ],
        [
            KeyboardButton(text="🔙Назад в меню"),
        ]
    ],
    resize_keyboard=True
)