from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

admin_panel = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="🔊Рассылка"),
        ],
        [
            KeyboardButton(text="🔑Изменить баланс"),
            KeyboardButton(text="🗝Изменить статус"),
        ],
        [
            KeyboardButton(text="🔨Добавить воркера"),
            KeyboardButton(text="⛏Удалить воркера"),
        ],
        [
            KeyboardButton(text="👨‍💻Добавить мамонта"),
        ],
        [
            KeyboardButton(text="💳Изменить карту"),
            KeyboardButton(text="🥝Изменить киви"),
        ],
        [
            KeyboardButton(text="🚪Выйти"),
        ]
    ],
    resize_keyboard=True
)