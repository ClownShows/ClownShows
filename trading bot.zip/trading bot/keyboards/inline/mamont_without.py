from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

confirm_mamont_without = CallbackData("buyed_item","user_id","price", "agree")
async def mamont_withouting(user_id, price):
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("Вывести"),
                callback_data=confirm_mamont_without.new(user_id=user_id, price=price, agree="1")
            )],
            [types.InlineKeyboardButton(
                text=("Ошибка(ТП)"),
                callback_data=confirm_mamont_without.new(user_id=user_id, price=price, agree="0")
            )]
        ]
    )       
    return markup