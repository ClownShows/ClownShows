from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

async def start_rules_key():
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("✅Принять правила"),
                callback_data="accept"
            )]
        ]
    )       
    return markup