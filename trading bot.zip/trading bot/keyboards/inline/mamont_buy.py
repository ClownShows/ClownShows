from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

confirm_mamont = CallbackData("buyed_item","user_id","price")
async def mamont_buying(user_id, price):
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("✅Подтвердить оплату"),
                callback_data=confirm_mamont.new(user_id=user_id, price=price)
            )],
            [types.InlineKeyboardButton(
                text=("Скрыть"),
                callback_data="wash"
            )]
        ]
    )       
    return markup