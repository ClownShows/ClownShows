from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

async def mamont_list():
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("🗑️Удалить всех мамонтов"),
                callback_data="delete_all_refferal_mamonts"
            )],
            [types.InlineKeyboardButton(
                text=("🔊Рассылка всем мамонтам"),
                callback_data="mailing_all_refferal_mamonts"
            )]
        ]
    )       
    return markup