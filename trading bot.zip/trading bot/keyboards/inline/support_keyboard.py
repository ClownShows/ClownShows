from aiogram.types import InlineKeyboardMarkup
from aiogram.types import InlineKeyboardButton
from aiogram.types import ReplyKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

btnsupport = InlineKeyboardButton('Перейти', url='t.me/FavoritTrade_Support')
kb_support = InlineKeyboardMarkup().add(btnsupport)