from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

async def cancel_func():
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("Отменить действие"),
                callback_data="cancel"
            )]
        ]
    )       
    return markup
