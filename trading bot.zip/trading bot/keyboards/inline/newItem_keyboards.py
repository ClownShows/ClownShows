from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

async def newItem_added_keyboard():
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("✅Подтвердить добавление товара"),
                callback_data="confirm"
            )],
            [types.InlineKeyboardButton(
                text=("🛠Отредактировать с начала"),
                callback_data="edit"
            )],
            [types.InlineKeyboardButton(
                text=("🔙Назад"),
                callback_data="back"
            )]
        ]
    )       
    return markup

async def newItem_edit_keyboard():
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("🔙Назад"),
                callback_data="back"
            )]
        ]
    )       
    return markup