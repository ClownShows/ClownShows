from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
from aiogram import types

mamont_menu = CallbackData("mamont_menu","user_id", "action")
async def mamont_menu_keyboard(user_id):
    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text=("Удалить мамонта🗑️"),
                callback_data=mamont_menu.new(user_id=user_id, action="0")
            )],
            [types.InlineKeyboardButton(
                text=("Изменить баланс💰"),
                callback_data=mamont_menu.new(user_id=user_id, action="1")
            )],
            [types.InlineKeyboardButton(
                text=("Изменить статус📌"),
                callback_data=mamont_menu.new(user_id=user_id, action="2")
            )],
            [types.InlineKeyboardButton(
                text=("Написать сообщение🔊"),
                callback_data=mamont_menu.new(user_id=user_id, action="3")
            )],
            [types.InlineKeyboardButton(
                text=("Лимит выигрыша"),
                callback_data=mamont_menu.new(user_id=user_id, action="4")
            )]
        ]
    )       
    return markup