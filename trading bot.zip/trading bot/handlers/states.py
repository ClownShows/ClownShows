from aiogram.dispatcher.filters.state import StatesGroup, State

class Paymenting(StatesGroup):
    Pay_Money = State()
    Payed_Money = State()
    Get_Money = State()
    Payed_Card = State()
    Activate_Coupon = State()

class Casino(StatesGroup):
    Start_give_money = State()
    Choose_variable = State()
    Hands_give_money = State()
    Hands_choose= State()
    Coin_give_money = State()
    Coin_choose= State()
    Dice_give_money = State()
    Dice_choose= State()

class Mailing(StatesGroup):
    Mailing_Text = State()

class Admin_Edit(StatesGroup):
    Admin_Edit_Text_Link = State()
    Admin_Edit_Text_Price = State()

class Admin_Edit_Status(StatesGroup):
    Admin_Edit_Text_Link = State()
    Admin_Edit_Text_Price = State()

class Admin_Add_Mamont(StatesGroup):
    Admin_Edit_Text_Link = State()
    Admin_Edit_Text_Price = State()

class Admin_Add_Worker(StatesGroup):
    Admin_Edit_Text_Link = State()

class Admin_Delete_Worker(StatesGroup):
    Admin_Edit_Text_Link = State()

class Worker_Edit(StatesGroup):
    Worker_Edit_Text_Link = State()
    Worker_Edit_Text_Price = State()

class Worker_Edit_Status(StatesGroup):
    Worker_Edit_Text_Link = State()
    Worker_Edit_Text_Price = State()

class Worker_Add_Coupon(StatesGroup):
    Worker_Add_Coupon_Add = State()

class Worker_Mailing_Mamonts(StatesGroup):
    Worker_Mailing_Mamont = State()

class Worker_Limit_Mamonts(StatesGroup):
    Worker_Limit_Mamont = State()

class Worker_Mailing_Mamont(StatesGroup):
    Worker_Mailing_Mamont_End = State()

class Card_Edit_Status(StatesGroup):
    Card_Edit_Text_Link = State()

class Qiwi_Edit_Status(StatesGroup):
    Qiwi_Edit_Text_Link = State()