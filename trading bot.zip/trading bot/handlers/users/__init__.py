from .help import dp
from .start import dp
from .profile import dp
from .option import dp
from .casino import dp
from .worker import dp
from .echo import dp

__all__ = ["dp"]
