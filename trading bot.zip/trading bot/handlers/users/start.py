from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from loader import dp, bot
from utils.db_api.db_commands import add_user,get_user
from utils.db_api.database import db
from utils.db_api.models import User

from data.config import ADMINS

from utils.db_api.db_commands import update_user_payment, get_user_id_worked, edit_worker_user
from keyboards.inline.start_rules import start_rules_key
from keyboards.default.choose_payment_value import choose_payment, payments_list
from keyboards.default.start_menu_keyboards import start_menu

@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
    referral=message.get_args()

    old_user = await get_user(message.from_user.id)
    if old_user:
        await message.answer("Мы рады, что вы вернулись :)", reply_markup=start_menu)
        return 

    user = await add_user(referral=referral)
    id=user.id
    
    for adm in ADMINS:
        if(int(adm)==user.referral):
            await edit_worker_user(True,user.user_id)
            break

    bot_username = (await bot.me).username
    markup= await start_rules_key()
    await message.answer(f"Политика и условия пользования данным ботом.\n\n1️⃣ Принимая правила, Вы подтверждаете своё совершеннолетие.\n2️⃣ Запрещено использовать сторонне ПО, скрипты и боты с целью компроментации данных или взлома.\n3️⃣ Запрещается использовать мультиаккаунты.\n4️⃣ В случае выявления нарушения по вышеперечисленным правилам, Ваш аккаунт может быть временно заморожен до выяснения обстоятельств.\n5️⃣ Используя бота, Вы берёте все денежные риски на себя.\n6️⃣ В случае необходимости администрация имеет полное право запросить у Вас документы, подтверждающие Вашу личность и совершеннолетие.\n7️⃣ Администрация может запрашивать прохождение верификации личности для всех новых игроков, которая может длиться до 48 часов.\n8️⃣ Вы играете  на виртуальные деньги, приобретая их за реальные средства.\n9️⃣ Все входящие извне транзакции в боте являются благотворительностью.\n\n📌 Если в ходе использования бота у вас возникли какие-нибудь затруднения или вопросы - обращайтесь в поддержку.\n\n⚠️ Внимание! Обращение в поддержку должно быть сразу по делу. Старайтесь изложить свои мысли чётко и ясно, чтоб у поддержки не возникло затруднений и она могла быстро, а так же качественно Вас обслужить.\n\nСпасибо за понимание и удачи в игре 😉\n",reply_markup=markup )

@dp.callback_query_handler(text_contains="accept")
async def bot_start_rules_accept(call: types.CallbackQuery):
    await call.message.answer("⚠️Для начала нужно выбрать валюту вашего профиля", reply_markup=choose_payment)

@dp.message_handler(text="Выбрать валюту")
async def choose_paymented(message: types.Message):
    await message.answer("Выберите валюту", reply_markup=payments_list)

@dp.message_handler(text="UAH🇺🇦")
async def choose_UAH(message: types.Message):
    user=await get_user(message.from_user.id)
    if(user.cash==0):
        await update_user_payment("UAH", message.from_user.id)
        await message.answer("Ваша основная валюта теперь: UAH🇺🇦", reply_markup=start_menu)
    else:
        await message.answer("Вы не можете изменить валюту, пока ваш баланс не равен 0!", reply_markup=start_menu)

@dp.message_handler(text="RUB🇷🇺")
async def choose_RUB(message: types.Message):
    user=await get_user(message.from_user.id)
    if(user.cash==0):
        await update_user_payment("RUB", message.from_user.id)
        await message.answer("Ваша основная валюта теперь: RUB🇷🇺", reply_markup=start_menu)
    else:
        await message.answer("Вы не можете изменить валюту, пока ваш баланс не равен 0!", reply_markup=start_menu)

@dp.message_handler(text="BYN🇧🇾")
async def choose_BYN(message: types.Message):
    user=await get_user(message.from_user.id)
    if(user.cash==0):
        await update_user_payment("BYN", message.from_user.id)
        await message.answer("Ваша основная валюта теперь: BYN🇧🇾", reply_markup=start_menu)
    else:
        await message.answer("Вы не можете изменить валюту, пока ваш баланс не равен 0!", reply_markup=start_menu)