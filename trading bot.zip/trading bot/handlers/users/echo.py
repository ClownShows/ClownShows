from aiogram import types
from aiogram.dispatcher import FSMContext

from loader import dp
from handlers.users.worker import work_panel_mamont
from keyboards.default.start_menu_keyboards import start_menu

# Эхо хендлер, куда летят текстовые сообщения без указанного состояния
@dp.message_handler(state=None)
async def bot_echo(message: types.Message):
    if(message.text[0]=="/"):
        if(message.text[1]=="u"):
            await work_panel_mamont(message)
        else:
            await message.answer(f"Что-то пошло не так!", reply_markup=start_menu)
    else:
        await message.answer(f"Что-то пошло не так!", reply_markup=start_menu)


# Эхо хендлер, куда летят ВСЕ сообщения с указанным состоянием
@dp.message_handler(state="*", content_types=types.ContentTypes.ANY)
async def bot_echo_all(message: types.Message, state: FSMContext):
    await message.answer(f"Что-то пошло не так!")
    await state.reset_state()
