from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from loader import dp, bot
from utils.db_api.db_commands import add_user
from utils.db_api.database import db
from utils.db_api.models import User

import random
from utils.db_api.db_commands import update_user_payment, get_user,add_money_user,dec_money_user, update_addmoney, edit_status_user
from keyboards.inline.start_rules import start_rules_key
from keyboards.default.choose_payment_value import choose_payment, payments_list
from keyboards.default.casino_keyboards import game_stop, choose_var,choose_hands,choose_coin, choose_dice
from keyboards.default.start_menu_keyboards import start_menu
from keyboards.default.choose_game import choosed_game
from handlers.states import Casino
from aiogram.dispatcher import FSMContext
from markdown import Markdown

@dp.message_handler(text="📈 Мой ECN счёт")
async def bot_start_games(message: types.Message):
    user = await get_user(message.from_user.id)
    await message.answer(text="📈Выберите актив:",reply_markup=choosed_game)

@dp.message_handler(text="↪️ Назад")
async def gabes_back(message: types.Message):
    user = await get_user(message.from_user.id)
    await message.answer(text="Вы вернулись в главное меню!",reply_markup=start_menu)
#УГАДАЙ ЧИСЛО

#ПРОВЕРКА ЛИМИТА
async def check_limit(user):
    if(user.limit_casino!=0):
        if(user.cash>user.limit_casino):
            await edit_status_user(3, user.user_id)

@dp.message_handler(text="Amazon")
async def bot_start_gamea(message: types.Message):
    user = await get_user(message.from_user.id)
    await check_limit(user)
    with open('amazon.jpg', 'rb') as pic:
      await bot.send_photo(chat_id=message.from_user.id,photo=pic,caption=f"💰*Введите сумму инвестиции*\n\n💵*Ваш баланс : {user.cash} {user.payment}*💰\n⚠️*Минимальная сумма инвестиции 100 {user.payment}*",reply_markup=game_stop,parse_mode='Markdown')
    pic.close()
    await Casino.Start_give_money.set()


@dp.message_handler(state=Casino.Start_give_money)
async def pay_money_start(message: types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        if(message.text=="Закончить инвестирование"):
            await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown')
            await state.reset_state()
        else:
            await message.answer("*⛔️Неправильно, Введите число!*")
            return
    user = await get_user(message.from_user.id)
    if(user.cash >= price):
        if(user.payment=="BYN"):
            if(price<10):
                text = f"*Минимальная сумма ставки 10 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
        else:
            if(price<100):
                text = f"*Минимальная сумма инвестиции 100 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
    else:
        text = "*На Вашем счету недостаточно средств*❌"
        await message.answer(text)

@dp.message_handler(text="Вверх📈",state=Casino.Choose_variable)
async def choose_1(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(1,49)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(50,100)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number<50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

@dp.message_handler(text="Не изменится",state=Casino.Choose_variable)
async def choose_2(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=50
        await win_casino10(message,user)
    if(user.casino_hack=='2'):
        random_choose=random.randint(1,2)
        if(random_choose==1):
            random_number=random.randint(1,49)
        else:
            random_number=random.randint(51,100)
        await lose_casino10(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number==50):
            await win_casino10(message,user)
        else:
            await lose_casino10(message,user,random_number)

@dp.message_handler(text="Вниз📉",state=Casino.Choose_variable)
async def choose_3(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(51,100)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(1,49)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number>50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)


async def lose_casino10(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"*😥 К сожалению, вы проиграли 😥\nВаш прогноз был не верный!*❌")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino10(message: types.Message, user):
    await add_money_user(user.add_money*9,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino(message: types.Message, user, random_numb):
    await add_money_user(user.add_money,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def lose_casino(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"😥* К сожалению, вы проиграли 😥\n\nВаш прогноз был не верный!*❌\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)


@dp.message_handler(text="Закончить инвестирование")
async def back_to_menu_inpay(message: types.Message):
    await message.answer(f"*Вы закончили инвестирование*", reply_markup=choosed_game,parse_mode='Markdown')

@dp.message_handler(text="Закончить инвестирование", state=Casino)
async def back_to_menu(message: types.Message, state: FSMContext):
    await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown' )
    await state.reset_state()

########################################################################################################
@dp.message_handler(text="Apple")
async def bot_start_gamea(message: types.Message):
    user = await get_user(message.from_user.id)
    await check_limit(user)
    with open('amazon.jpg', 'rb') as pic:
      await bot.send_photo(chat_id=message.from_user.id,photo=pic,caption=f"💰*Введите сумму инвестиции\n\n💵Ваш баланс : {user.cash} {user.payment}💰\n💸Минимальная сумма инвестиции 100 {user.payment}*",reply_markup=game_stop,parse_mode='Markdown')
    pic.close()
    await Casino.Start_give_money.set()


@dp.message_handler(state=Casino.Start_give_money)
async def pay_money_start(message: types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        if(message.text=="Закончить инвестирование"):
            await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown')
            await state.reset_state()
        else:
            await message.answer("*⛔️Неправильно, Введите число!*")
            return
    user = await get_user(message.from_user.id)
    if(user.cash >= price):
        if(user.payment=="BYN"):
            if(price<10):
                text = f"*Минимальная сумма ставки 10 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
        else:
            if(price<100):
                text = f"*Минимальная сумма инвестиции 100 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
    else:
        text = "*На Вашем счету недостаточно средств*❌"
        await message.answer(text)

@dp.message_handler(text="Вверх📈",state=Casino.Choose_variable)
async def choose_1(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(1,49)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(50,100)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number<50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

@dp.message_handler(text="Не изменится",state=Casino.Choose_variable)
async def choose_2(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=50
        await win_casino10(message,user)
    if(user.casino_hack=='2'):
        random_choose=random.randint(1,2)
        if(random_choose==1):
            random_number=random.randint(1,49)
        else:
            random_number=random.randint(51,100)
        await lose_casino10(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number==50):
            await win_casino10(message,user)
        else:
            await lose_casino10(message,user,random_number)

@dp.message_handler(text="Вниз📉",state=Casino.Choose_variable)
async def choose_3(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(51,100)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(1,49)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number>50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

async def lose_casino10(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"*😥 К сожалению, вы проиграли 😥\nВаш прогноз был не верный!*❌")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino10(message: types.Message, user):
    await add_money_user(user.add_money*9,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino(message: types.Message, user, random_numb):
    await add_money_user(user.add_money,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def lose_casino(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"😥* К сожалению, вы проиграли 😥\n\nВаш прогноз был не верный!*❌\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)


@dp.message_handler(text="Закончить инвестирование")
async def back_to_menu_inpay(message: types.Message):
    await message.answer(f"*Вы закончили инвестирование*", reply_markup=choosed_game,parse_mode='Markdown')

@dp.message_handler(text="*Закончить инвестирование*", state=Casino)
async def back_to_menu(message: types.Message, state: FSMContext):
    await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown' )
    await state.reset_state()

###########################################################

@dp.message_handler(text="Bitcoin")
async def bot_start_gamea(message: types.Message):
    user = await get_user(message.from_user.id)
    await check_limit(user)
    with open('amazon.jpg', 'rb') as pic:
      await bot.send_photo(chat_id=message.from_user.id,photo=pic,caption=f"💰*Введите сумму инвестиции\n\n💵Ваш баланс : {user.cash} {user.payment}💰\n💸Минимальная сумма инвестиции 100 {user.payment}*",reply_markup=game_stop,parse_mode='Markdown')
    pic.close()
    await Casino.Start_give_money.set()


@dp.message_handler(state=Casino.Start_give_money)
async def pay_money_start(message: types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        if(message.text=="Закончить инвестирование"):
            await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown')
            await state.reset_state()
        else:
            await message.answer("*⛔️Неправильно, Введите число!*")
            return
    user = await get_user(message.from_user.id)
    if(user.cash >= price):
        if(user.payment=="BYN"):
            if(price<10):
                text = f"*Минимальная сумма ставки 10 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
        else:
            if(price<100):
                text = f"*Минимальная сумма инвестиции 100 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
    else:
        text = "*На Вашем счету недостаточно средств*❌"
        await message.answer(text)

@dp.message_handler(text="Вверх📈",state=Casino.Choose_variable)
async def choose_1(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(1,49)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(50,100)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number<50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

@dp.message_handler(text="Не изменится",state=Casino.Choose_variable)
async def choose_2(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=50
        await win_casino10(message,user)
    if(user.casino_hack=='2'):
        random_choose=random.randint(1,2)
        if(random_choose==1):
            random_number=random.randint(1,49)
        else:
            random_number=random.randint(51,100)
        await lose_casino10(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number==50):
            await win_casino10(message,user)
        else:
            await lose_casino10(message,user,random_number)

@dp.message_handler(text="Вниз📉",state=Casino.Choose_variable)
async def choose_3(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(51,100)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(1,49)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number>50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)


async def lose_casino10(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"*😥 К сожалению, вы проиграли 😥\nВаш прогноз был не верный!*❌")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino10(message: types.Message, user):
    await add_money_user(user.add_money*9,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino(message: types.Message, user, random_numb):
    await add_money_user(user.add_money,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def lose_casino(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"😥* К сожалению, вы проиграли 😥\n\nВаш прогноз был не верный!*❌\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)


@dp.message_handler(text="Закончить инвестирование")
async def back_to_menu_inpay(message: types.Message):
    await message.answer(f"*Вы закончили инвестирование*", reply_markup=choosed_game,parse_mode='Markdown')

@dp.message_handler(text="*Закончить инвестирование*", state=Casino)
async def back_to_menu(message: types.Message, state: FSMContext):
    await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown' )
    await state.reset_state()

############################################################################################

@dp.message_handler(text="Ethereum")
async def bot_start_gamea(message: types.Message):
    user = await get_user(message.from_user.id)
    await check_limit(user)
    with open('amazon.jpg', 'rb') as pic:
      await bot.send_photo(chat_id=message.from_user.id,photo=pic,caption=f"💰*Введите сумму инвестиции\n\n💵Ваш баланс : {user.cash} {user.payment}💰\n💸Минимальная сумма инвестиции 100 {user.payment}*",reply_markup=game_stop,parse_mode='Markdown')
    pic.close()
    await Casino.Start_give_money.set()


@dp.message_handler(state=Casino.Start_give_money)
async def pay_money_start(message: types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        if(message.text=="Закончить инвестирование"):
            await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown')
            await state.reset_state()
        else:
            await message.answer("*⛔️Неправильно, Введите число!*")
            return
    user = await get_user(message.from_user.id)
    if(user.cash >= price):
        if(user.payment=="BYN"):
            if(price<10):
                text = f"*Минимальная сумма ставки 10 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
        else:
            if(price<100):
                text = f"*Минимальная сумма инвестиции 100 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
    else:
        text = "*На Вашем счету недостаточно средств*❌"
        await message.answer(text)

@dp.message_handler(text="Вверх📈",state=Casino.Choose_variable)
async def choose_1(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(1,49)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(50,100)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number<50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

@dp.message_handler(text="Не изменится",state=Casino.Choose_variable)
async def choose_2(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=50
        await win_casino10(message,user)
    if(user.casino_hack=='2'):
        random_choose=random.randint(1,2)
        if(random_choose==1):
            random_number=random.randint(1,49)
        else:
            random_number=random.randint(51,100)
        await lose_casino10(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number==50):
            await win_casino10(message,user)
        else:
            await lose_casino10(message,user,random_number)

@dp.message_handler(text="Вниз📉",state=Casino.Choose_variable)
async def choose_3(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(51,100)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(1,49)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number>50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

async def lose_casino10(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"*😥 К сожалению, вы проиграли 😥\nВаш прогноз был не верный!*❌")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino10(message: types.Message, user):
    await add_money_user(user.add_money*9,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino(message: types.Message, user, random_numb):
    await add_money_user(user.add_money,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def lose_casino(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"😥* К сожалению, вы проиграли 😥\n\nВаш прогноз был не верный!*❌\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)


@dp.message_handler(text="Закончить инвестирование")
async def back_to_menu_inpay(message: types.Message):
    await message.answer(f"*Вы закончили инвестирование*", reply_markup=choosed_game,parse_mode='Markdown')

@dp.message_handler(text="*Закончить инвестирование*", state=Casino)
async def back_to_menu(message: types.Message, state: FSMContext):
    await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown' )
    await state.reset_state()


#########################################################################################################################

@dp.message_handler(text="Tesla")
async def bot_start_gamea(message: types.Message):
    user = await get_user(message.from_user.id)
    await check_limit(user)
    with open('amazon.jpg', 'rb') as pic:
      await bot.send_photo(chat_id=message.from_user.id,photo=pic,caption=f"💰*Введите сумму инвестиции\n\n💵Ваш баланс : {user.cash} {user.payment}💰\n💸Минимальная сумма инвестиции 100 {user.payment}*",reply_markup=game_stop,parse_mode='Markdown')
    pic.close()
    await Casino.Start_give_money.set()


@dp.message_handler(state=Casino.Start_give_money)
async def pay_money_start(message: types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        if(message.text=="Закончить инвестирование"):
            await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown')
            await state.reset_state()
        else:
            await message.answer("*⛔️Неправильно, Введите число!*")
            return
    user = await get_user(message.from_user.id)
    if(user.cash >= price):
        if(user.payment=="BYN"):
            if(price<10):
                text = f"*Минимальная сумма ставки 10 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
        else:
            if(price<100):
                text = f"*Минимальная сумма инвестиции 100 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
    else:
        text = "*На Вашем счету недостаточно средств*❌"
        await message.answer(text)

@dp.message_handler(text="Вверх📈",state=Casino.Choose_variable)
async def choose_1(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(1,49)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(50,100)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number<50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

@dp.message_handler(text="Не изменится",state=Casino.Choose_variable)
async def choose_2(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=50
        await win_casino10(message,user)
    if(user.casino_hack=='2'):
        random_choose=random.randint(1,2)
        if(random_choose==1):
            random_number=random.randint(1,49)
        else:
            random_number=random.randint(51,100)
        await lose_casino10(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number==50):
            await win_casino10(message,user)
        else:
            await lose_casino10(message,user,random_number)

@dp.message_handler(text="Вниз📉",state=Casino.Choose_variable)
async def choose_3(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(51,100)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(1,49)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number>50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)


async def lose_casino10(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"*😥 К сожалению, вы проиграли 😥\nВаш прогноз был не верный!*❌")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino10(message: types.Message, user):
    await add_money_user(user.add_money*9,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino(message: types.Message, user, random_numb):
    await add_money_user(user.add_money,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def lose_casino(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"😥* К сожалению, вы проиграли 😥\n\nВаш прогноз был не верный!*❌\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

@dp.message_handler(text="Закончить инвестирование")
async def back_to_menu_inpay(message: types.Message):
    await message.answer(f"*Вы закончили инвестирование*", reply_markup=choosed_game,parse_mode='Markdown')

@dp.message_handler(text="*Закончить инвестирование*", state=Casino)
async def back_to_menu(message: types.Message, state: FSMContext):
    await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown' )
    await state.reset_state()


##################################################################################################################


@dp.message_handler(text="Intel")
async def bot_start_gamea(message: types.Message):
    user = await get_user(message.from_user.id)
    await check_limit(user)
    with open('amazon.jpg', 'rb') as pic:
      await bot.send_photo(chat_id=message.from_user.id,photo=pic,caption=f"💰*Введите сумму инвестиции\n\n💵Ваш баланс : {user.cash} {user.payment}💰\n💸Минимальная сумма инвестиции 100 {user.payment}*",reply_markup=game_stop,parse_mode='Markdown')
    pic.close()
    await Casino.Start_give_money.set()

@dp.message_handler(state=Casino.Start_give_money)
async def pay_money_start(message: types.Message, state: FSMContext):
    try:
        price = int(message.text)
    except ValueError:
        if(message.text=="Закончить инвестирование"):
            await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown')
            await state.reset_state()
        else:
            await message.answer("*⛔️Неправильно, Введите число!*")
            return
    user = await get_user(message.from_user.id)
    if(user.cash >= price):
        if(user.payment=="BYN"):
            if(price<10):
                text = f"*Минимальная сумма ставки 10 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
        else:
            if(price<100):
                text = f"*Минимальная сумма инвестиции 100 {user.payment}*"
                await message.answer(text)
            else:
                await update_addmoney(message.from_user.id,price)
                text = "*🤔 Куда пойдет курс актива? 🤔\n\n📈 Коэффициенты:\nВверх - x2\nНе изменится - x10\nВниз - x2*"
                await message.answer(text, reply_markup=choose_var,parse_mode='Markdown')
                await Casino.Choose_variable.set()
    else:
        text = "*На Вашем счету недостаточно средств*❌"
        await message.answer(text)

@dp.message_handler(text="Вверх📈",state=Casino.Choose_variable)
async def choose_1(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(1,49)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(50,100)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number<50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)

@dp.message_handler(text="Не изменится",state=Casino.Choose_variable)
async def choose_2(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=50
        await win_casino10(message,user)
    if(user.casino_hack=='2'):
        random_choose=random.randint(1,2)
        if(random_choose==1):
            random_number=random.randint(1,49)
        else:
            random_number=random.randint(51,100)
        await lose_casino10(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number==50):
            await win_casino10(message,user)
        else:
            await lose_casino10(message,user,random_number)

@dp.message_handler(text="Вниз📉",state=Casino.Choose_variable)
async def choose_3(message: types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if(user.casino_hack=='1'):
        random_number=random.randint(51,100)
        await win_casino(message,user,random_number)
    if(user.casino_hack=='2'):
        random_number=random.randint(1,49)
        await lose_casino(message,user,random_number)
    if(user.casino_hack=='3'):
        random_number=random.randint(1,100)
        if(random_number>50):
            await win_casino(message,user,random_number)
        else:
            await lose_casino(message,user,random_number)


async def lose_casino10(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"*😥 К сожалению, вы проиграли 😥\nВаш прогноз был не верный!*❌")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino10(message: types.Message, user):
    await add_money_user(user.add_money*9,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def win_casino(message: types.Message, user, random_numb):
    await add_money_user(user.add_money,message.from_user.id)
    text = (f"*🤑 Вы выиграли 🤑\n\nВаш прогноз был верный!*✅\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)

async def lose_casino(message: types.Message, user, random_numb):
    await dec_money_user(user.add_money,message.from_user.id)
    text = (f"😥* К сожалению, вы проиграли 😥\n\nВаш прогноз был не верный!*❌\n")
    await message.answer(text,reply_markup=game_stop,parse_mode='Markdown')
    await bot_start_game(message)


@dp.message_handler(text="Закончить инвестирование")
async def back_to_menu_inpay(message: types.Message):
    await message.answer(f"*Вы закончили инвестирование*", reply_markup=choosed_game,parse_mode='Markdown')

@dp.message_handler(text="*Закончить инвестирование*", state=Casino)
async def back_to_menu(message: types.Message, state: FSMContext):
    await message.answer(f"*Вы закончили инвестирование!*", reply_markup=choosed_game,parse_mode='Markdown' )
    await state.reset_state()


