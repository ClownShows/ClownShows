from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandHelp

from loader import dp


@dp.message_handler(text="🔮Контакты")
async def bot_help(message: types.Message):
    text = ("Наш официалый сайт - favorit-casino.net \n\nНаш Instagram - instagram.com/favbet \n\nТехническая Поддержка - @FavoritSupport ")
    await message.answer(text)
