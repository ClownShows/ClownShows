from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from loader import dp, bot
from utils.db_api.db_commands import add_user
from utils.db_api.database import db
from utils.db_api.models import User

import random
from utils.db_api.db_commands import update_user_payment, get_user
from keyboards.inline.start_rules import start_rules_key
from keyboards.default.choose_payment_value import choose_payment, payments_list
from keyboards.default.option_choose_payment import option_key
from keyboards.inline.support_keyboard import kb_support
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton


@dp.message_handler(text="Настройки⚒")
async def open_profile(message: types.Message):
    await message.answer("Выбирите действие⚙️", reply_markup=option_key)

@dp.message_handler(text="🛠Техническая Поддержка🛠")
async def open_profile(message: types.Message):
    await message.answer("Техническая Поддержка🛠", reply_markup=kb_support)


@dp.message_handler(text="💵Сменить валюту💶")
async def open_profile(message: types.Message):
    await message.answer("Вы можете сменить валюту", reply_markup=choose_payment)