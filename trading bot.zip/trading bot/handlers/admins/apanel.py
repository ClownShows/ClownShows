from typing import Union

import asyncio

from data.config import ADMINS, CHANNEL_ID

from aiogram import Bot
from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher import FSMContext

from loader import dp, bot

from keyboards.default.admin_panel_keyboards import admin_panel
from keyboards.default.start_menu_keyboards import start_menu
from handlers.states import Mailing, Admin_Edit, Admin_Edit_Status, Admin_Add_Worker, Admin_Delete_Worker, Admin_Add_Mamont, Card_Edit_Status, Qiwi_Edit_Status
from utils.db_api.db_commands import get_user_from_edit, edit_money_user, get_user, update_addmoney, edit_status_user, edit_worker_user, add_mamont, add_money_user, get_user_about_id, get_card_number, set_card_number
from utils.db_api.models import User, Cards
from keyboards.inline.mamont_buy import confirm_mamont

@dp.message_handler(user_id=ADMINS, commands=["apanel"])
async def admin_panel_start(message: types.Message):
    await message.answer(f"🕵️‍♂️Меню Администратора, {message.from_user.full_name}",reply_markup=admin_panel)

@dp.message_handler(user_id=ADMINS, commands=["cancel"])
async def admin_panel_cancel_mailing(message: types.Message):
    await message.answer(f"Вы отменили действие!",reply_markup=admin_panel)
#--------------------------------------------------------------РАССЫЛКА---------------------------------------------------------------------------------

@dp.message_handler(user_id=ADMINS, text="🔊Рассылка")
async def admin_panel_pushing(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите текст рассылки:")
    await Mailing.Mailing_Text.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Mailing)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Mailing.Mailing_Text)
async def admin_panel_mailing_text(message: types.Message, state: FSMContext):
    text = message.text
    await state.update_data(text=text)
    users = await User.query.gino.all()
    for user in users:
        try:
            await bot.send_message(chat_id=user.user_id, text=text)
            await sleep(0.3)
        except Exception:
            pass
    await message.answer("🔥Рассылка успешно выполнена🔥")
    await state.reset_state()
#--------------------------------------------------------------ИЗМЕНИТЬ БАЛАНС---------------------------------------------------------------------------------
@dp.message_handler(user_id=ADMINS, text="🔑Изменить баланс")
async def admin_panel_edit_cash(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите id пользователя:")
    await Admin_Edit.Admin_Edit_Text_Link.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Admin_Edit)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Admin_Edit.Admin_Edit_Text_Link)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    id_user = int(message.text)
    await update_addmoney(message.from_user.id, id_user)
    await message.answer("Для отмены введите /cancel\nВведите новый баланс пользователя:")
    await Admin_Edit.Admin_Edit_Text_Price.set()

@dp.message_handler(user_id=ADMINS, state=Admin_Edit.Admin_Edit_Text_Price)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    await edit_money_user(message.text, user.add_money)
    user = await get_user(user.add_money)
    await update_addmoney(message.from_user.id, 0)
    text = f"Баланс изменен:\nId: {user.user_id} | Username: {user.full_name} | Login: @{user.username} | Cash: {user.cash}\n"
    await message.answer(text, parse_mode=None)
    await state.reset_state()
#--------------------------------------------------------------ИЗМЕНИТЬ СТАТУС---------------------------------------------------------------------------------
@dp.message_handler(user_id=ADMINS, text="🗝Изменить статус")
async def admin_panel_edit_cash(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите id пользователя:")
    await Admin_Edit_Status.Admin_Edit_Text_Link.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Admin_Edit_Status)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Admin_Edit_Status.Admin_Edit_Text_Link)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    id_user = int(message.text)
    await update_addmoney(message.from_user.id, id_user)
    await message.answer("Для отмены введите /cancel\nВведите новый статус пользователя \n1-Выйгрыш\n2-Проигрыш\n3-Рандом:")
    await Admin_Edit_Status.Admin_Edit_Text_Price.set()

@dp.message_handler(user_id=ADMINS, state=Admin_Edit_Status.Admin_Edit_Text_Price)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    if(message.text!='1' or message.text!='2' or message.text!='3'):
        await message.answer("Для отмены введите /cancel\nВведите число от 1 до 3!")
    user = await get_user(message.from_user.id)
    await edit_status_user(message.text, user.add_money)
    user = await get_user(user.add_money)
    await update_addmoney(message.from_user.id, 0)
    text = f"Статус изменен:\nId: {user.user_id} | Username: {user.full_name} | Login: @{user.username} | Status: {user.casino_hack}\n"
    await message.answer(text, parse_mode=None)
    await state.reset_state()
#--------------------------------------------------------------ДОБАВИТЬ ВОРКЕРА---------------------------------------------------------------------------------
@dp.message_handler(user_id=ADMINS, text="🔨Добавить воркера")
async def admin_panel_edit_cash(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите id пользователя:")
    await Admin_Add_Worker.Admin_Edit_Text_Link.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Admin_Add_Worker)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Admin_Add_Worker.Admin_Edit_Text_Link)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    id_user = int(message.text)
    await edit_worker_user(True,id_user)
    user = await get_user(id_user)
    text = f"Id: {user.user_id} | Username: {user.full_name} | Login: @{user.username} | Worker: {user.worker}\n"
    await message.answer(text, parse_mode=None)
    await state.reset_state()

#--------------------------------------------------------------УДАЛИТЬ ВОРКЕРА---------------------------------------------------------------------------------
@dp.message_handler(user_id=ADMINS, text="⛏Удалить воркера")
async def admin_panel_edit_cash(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите id пользователя:")
    await Admin_Delete_Worker.Admin_Edit_Text_Link.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Admin_Delete_Worker)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Admin_Delete_Worker.Admin_Edit_Text_Link)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    id_user = int(message.text)
    await edit_worker_user(False,id_user)
    user = await get_user(id_user)
    text = f"Id: {user.user_id} | Username: {user.full_name} | Login: @{user.username} | Worker: {user.worker}\n"
    await message.answer(text, parse_mode=None)
    await state.reset_state()
#---------------------------------------------------------ДОБАВИТЬ МАМОНТА----------------------------------------------------------
@dp.message_handler(user_id=ADMINS, text="👨‍💻Добавить мамонта")
async def admin_panel_edit_cash(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите id воркера:")
    await Admin_Add_Mamont.Admin_Edit_Text_Link.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Admin_Add_Mamont)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Admin_Add_Mamont.Admin_Edit_Text_Link)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    id_user = int(message.text)
    await update_addmoney(message.from_user.id, id_user)
    await message.answer("Для отмены введите /cancel\nВведите id мамонта:")
    await Admin_Add_Mamont.Admin_Edit_Text_Price.set()

@dp.message_handler(user_id=ADMINS, state=Admin_Add_Mamont.Admin_Edit_Text_Price)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    await add_mamont(user.add_money,int(message.text))
    text = f"Мамонт присвоен воркеру"
    await update_addmoney(message.from_user.id, 0)
    await message.answer(text)
    await state.reset_state()
#-----------------------------------------------------------ИЗМЕНИТЬ КАРТУ------------------------------------------------------------------
@dp.message_handler(user_id=ADMINS, text="💳Изменить карту")
async def admin_panel_edit_cash(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите новый номер карты:")
    await Card_Edit_Status.Card_Edit_Text_Link.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Card_Edit_Status)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Card_Edit_Status.Card_Edit_Text_Link)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    card_number = message.text
    await set_card_number(2, card_number)
    card = await get_card_number(2)
    await message.answer(f"Новый номер карты: {card.card_number}")
    await state.reset_state()

#---------------------------------------------------------ИЗМЕНЕНИЕ КИВИ-------------------------------------------------------------------------
@dp.message_handler(user_id=ADMINS, text="🥝Изменить киви")
async def admin_panel_edit_cash(message: types.Message):
    await message.answer("Для отмены введите /cancel\nВведите новый ник киви:")
    await Qiwi_Edit_Status.Qiwi_Edit_Text_Link.set()

@dp.message_handler(user_id=ADMINS, commands=["cancel"], state=Qiwi_Edit_Status)
async def admin_panel_cancel_mailing(message: types.Message, state: FSMContext):
    await message.answer(f"Вы отменили действие!")
    await state.reset_state()

@dp.message_handler(user_id=ADMINS, state=Qiwi_Edit_Status.Qiwi_Edit_Text_Link)
async def admin_panel_edit_cashing(message:types.Message, state: FSMContext):
    card_number = message.text
    await set_card_number(1, card_number)
    card = await get_card_number(1)
    await message.answer(f"Новый ник киви: {card.card_number}")
    await state.reset_state()

#-----------------------------------------------------------ПОДТВЕРЖДЕНИЕ ПЛАТЕЖА------------------------------------------------------------------
@dp.callback_query_handler(confirm_mamont.filter())
async def admin_panel_mamont_agree(call:types.CallbackQuery, callback_data: dict):
    user_id= int(callback_data.get('user_id'))
    price = int(callback_data.get('price'))
    usr= await get_user(user_id)
    work= await get_user(usr.referral)
    await add_money_user(price,user_id)
    await call.message.edit_text("Пополнен")
    text= (f"🥳 Успешное пополнение 🥳\n💵Сумма: {price} {usr.payment}\n✅Воркер: @{work.username}✅")
    await bot.send_message(chat_id=CHANNEL_ID, text=text)
    
@dp.callback_query_handler(user_id=ADMINS, text_contains="wash")
async def admin_panel_mamont_dcagree(call:types.CallbackQuery):
    await call.message.edit_text("Сообщение удалено")

#--------------------------------------------------------------ВЫХОД---------------------------------------------------------------------------------

@dp.message_handler(user_id=ADMINS, text="🚪Выйти")
async def admin_panel_out(message: types.Message):
    await message.answer(f"{message.from_user.full_name}, Вы вышли из админ панели",reply_markup=start_menu)


