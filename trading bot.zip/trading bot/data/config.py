from environs import Env

# Теперь используем вместо библиотеки python-dotenv библиотеку environs
env = Env()
env.read_env()

BOT_TOKEN = env.str("BOT_TOKEN")  # Забираем значение типа str
ADMINS = env.list("ADMINS")  # Тут у нас будет список из админов
IP = env.str("IP")  # Тоже str, но для айпи адреса хоста

CHANNEL_ID= env.int("CHANNEL_ID")

DB_USER=env.str("DB_USER")
DB_PASSWORD=env.str("DB_PASSWORD")
DB_NAME=env.str("DB_NAME")

QIWI_TOKEN=env.str("QIWI_TOKEN")

POSTGRESURI = f"postgresql://{DB_USER}:{DB_PASSWORD}@{IP}/{DB_NAME}"